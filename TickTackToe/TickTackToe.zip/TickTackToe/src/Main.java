public class Main
{
    public static void main(String[] args){
        gfx gfx = new gfx();


        gfx.gameWindow();
    }
}
